import cv2

# === Replace with your actual RTSP URL ===
rtsp_url = r"rtsp://admin:pass%40123@192.168.1.240:554/cam/realmonitor?channel=3&subtype=0"

# === Open RTSP stream ===
cap = cv2.VideoCapture(rtsp_url)
if not cap.isOpened():
    print("[ERROR] Unable to connect to RTSP stream.")
    exit()

print("[INFO] Connected to RTSP stream. Press 'q' to exit.")

while True:
    ret, frame = cap.read()
    if not ret:
        print("[WARNING] Failed to grab frame.")
        break

    frame = cv2.resize(frame, (640, 480))  # Optional: resize for display
    cv2.imshow("RTSP Stream", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
