

import sys
from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                             QPushButton, QLabel, QFileDialog, QGroupBox, QFrame)
from PyQt6.QtCore import Qt, QTimer, QPoint, QRect
from PyQt6.QtGui import QImage, QPixmap, QPainter, QPen, QColor, QFont
from ultralytics import YOLO
import cv2
import numpy as np

class VideoWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.image = QImage()
        self.rect = None
        self.drawing = False
        self.dragging = False
        self.drag_offset = QPoint(0, 0)
        self.fixed = False
        self.setMouseTracking(True)
        
    def set_image(self, image):
        self.image = image
        self.update()
        
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.drawImage(0, 0, self.image)
        
        if self.rect:
            if self.fixed:
                pen = QPen(QColor(0, 255, 0), 3, Qt.PenStyle.SolidLine)  # Green when fixed
            else:
                pen = QPen(QColor(255, 0, 0), 2, Qt.PenStyle.DashLine)  # Red dashed when movable
            painter.setPen(pen)
            painter.drawRect(self.rect)
            
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and not self.fixed:
            if self.rect and self.rect.contains(event.pos()):
                self.dragging = True
                self.drag_offset = event.pos() - self.rect.topLeft()
            else:
                self.rect = QRect(event.pos(), event.pos())
                self.drawing = True
                
    def mouseMoveEvent(self, event):
        if not self.fixed:
            if self.drawing:
                self.rect.setBottomRight(event.pos())
                self.update()
            elif self.dragging:
                self.rect.moveTo(event.pos() - self.drag_offset)
                self.update()
            
    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.drawing = False
            self.dragging = False
            
    def fix_rectangle(self):
        self.fixed = not self.fixed
        self.update()
