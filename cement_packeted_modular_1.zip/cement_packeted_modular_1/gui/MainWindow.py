import sys
import configparser
import os
from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                             QPushButton, QLabel, QFileDialog, QGroupBox, QFrame, QComboBox)
from PyQt6.QtCore import Qt, QTimer, QPoint, QRect
from PyQt6.QtGui import QImage, QPixmap, QPainter, QPen, QColor, QFont
from ultralytics import YOLO
import cv2
import numpy as np
from gui.VideoWidget import VideoWidget


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowIcon(QIcon(r"D:\cement_packeted_modular\gui\icons\cropped-cropped-logo.ico"))
        self.setWindowTitle("Cement Bag Counting By Kotai Electronics")
        self.setGeometry(100, 100, 1200, 800)
        
        # Variables
        self.video_path = ""
        self.cap = None
        self.playing = False
        self.counted_ids = set()
        self.cross_count = 0
        self.model = None
        self.current_frame = None
        self.TARGET_WIDTH = 800
        self.TARGET_HEIGHT = 600
        self.track_history = {}
        self.current_frame_position = 0
        
        # Load RTSP links from config file
        self.rtsp_links = self.load_rtsp_config()
        self.current_source = None  # 'video' or 'rtsp'
        
        # Load model
        try:
            self.model = YOLO(r"C:\Users\ayuba\Downloads\best (8).pt")
        except Exception as e:
            print(f"Error loading model: {e}")
            self.model = None
        
        # Create UI
        self.init_ui()
        
        # Timer for video playback
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_frame)
    
    def load_rtsp_config(self):
        """Load RTSP configuration from config file"""
        config = configparser.ConfigParser(interpolation=None)  # Disable interpolation
        config_path = os.path.join(os.path.dirname(__file__), 'config.ini')
        
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"Config file not found at: {config_path}")
        
        config.read(config_path)
        
        # Return the RTSP links in the required format
        return {
            "Camera 1": config.get('RTSP', 'Camera_1', raw=True),  # Use raw=True
            "Camera 2": config.get('RTSP', 'Camera_2', raw=True),  # Use raw=True
            "Custom RTSP": ""
        }
        
    def init_ui(self):
        # Main widget and layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(10, 10, 10, 10)
        
        # Left panel - controls
        control_panel = QGroupBox("Controls")
        control_panel.setStyleSheet("""
            QGroupBox {
                background: #34495e;
                border: 2px solid #2c3e50;
                border-radius: 5px;
                margin-top: 10px;
            }
            QGroupBox::title {
                color: #ecf0f1;
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 3px;
            }
        """)
        control_layout = QVBoxLayout()
        control_layout.setSpacing(15)
        
        # Title
        title = QLabel("Cement Bag Counting")
        title.setStyleSheet("""
            QLabel {
                color: #f39c12;
                font-size: 24px;
                font-weight: bold;
                padding: 10px;
            }
        """)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        control_layout.addWidget(title)
        
        # Separator
        separator = QFrame()
        separator.setFrameShape(QFrame.Shape.HLine)
        separator.setStyleSheet("color: #7f8c8d;")
        control_layout.addWidget(separator)
        
        # Source selection
        source_group = QGroupBox("Video Source")
        source_group.setStyleSheet("""
            QGroupBox {
                background: #2c3e50;
                border: 2px solid #34495e;
                border-radius: 5px;
            }
            QGroupBox::title {
                color: #ecf0f1;
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 3px;
            }
        """)
        source_layout = QVBoxLayout()
        
        # RTSP Camera dropdown
        self.rtsp_combo = QComboBox()
        self.rtsp_combo.addItems(list(self.rtsp_links.keys()))
        self.rtsp_combo.setCurrentIndex(-1)
        self.rtsp_combo.setStyleSheet("""
            QComboBox {
                background: #ecf0f1;
                padding: 5px;
                border-radius: 3px;
            }
        """)
        self.rtsp_combo.currentTextChanged.connect(self.rtsp_selected)
        source_layout.addWidget(QLabel("Select RTSP Camera:"))
        source_layout.addWidget(self.rtsp_combo)
        
        # Custom RTSP entry
        self.custom_rtsp_edit = QComboBox()
        self.custom_rtsp_edit.setEditable(True)
        self.custom_rtsp_edit.setPlaceholderText("Enter custom RTSP URL")
        self.custom_rtsp_edit.setStyleSheet("""
            QComboBox {
                background: #ecf0f1;
                padding: 5px;
                border-radius: 3px;
            }
        """)
        source_layout.addWidget(QLabel("Or enter custom RTSP:"))
        source_layout.addWidget(self.custom_rtsp_edit)
        
        # Connect button for RTSP
        self.connect_rtsp_btn = QPushButton("Connect RTSP")
        self.connect_rtsp_btn.setStyleSheet("""
            QPushButton {
                background: #3498db;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: #2980b9;
            }
            QPushButton:disabled {
                background: #95a5a6;
            }
        """)
        self.connect_rtsp_btn.clicked.connect(self.connect_to_rtsp)
        source_layout.addWidget(self.connect_rtsp_btn)
        
        # Or separator
        or_separator = QLabel("OR")
        or_separator.setAlignment(Qt.AlignmentFlag.AlignCenter)
        or_separator.setStyleSheet("color: #ecf0f1; font-weight: bold;")
        source_layout.addWidget(or_separator)
        
        # Upload button
        self.upload_btn = QPushButton("📁 Upload Video")
        self.upload_btn.setStyleSheet("""
            QPushButton {
                background: #3498db;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: #2980b9;
            }
            QPushButton:disabled {
                background: #95a5a6;
            }
        """)
        self.upload_btn.clicked.connect(self.upload_video)
        source_layout.addWidget(self.upload_btn)
        
        source_group.setLayout(source_layout)
        control_layout.addWidget(source_group)
        
        # Draw rectangle button
        self.draw_btn = QPushButton("🖌️ Draw Rectangle")
        self.draw_btn.setStyleSheet("""
            QPushButton {
                background: #9b59b6;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: #8e44ad;
            }
            QPushButton:disabled {
                background: #95a5a6;
            }
        """)
        self.draw_btn.clicked.connect(self.start_drawing_rect)
        self.draw_btn.setEnabled(False)
        control_layout.addWidget(self.draw_btn)
        
        # Fix rectangle button
        self.fix_btn = QPushButton("🔒 Fix Rectangle")
        self.fix_btn.setStyleSheet("""
            QPushButton {
                background: #e74c3c;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: #c0392b;
            }
            QPushButton:disabled {
                background: #95a5a6;
            }
        """)
        self.fix_btn.clicked.connect(self.toggle_fix_rectangle)
        self.fix_btn.setEnabled(False)
        control_layout.addWidget(self.fix_btn)
        
        # Start/Stop buttons
        btn_frame = QWidget()
        btn_layout = QHBoxLayout(btn_frame)
        btn_layout.setSpacing(10)
        
        self.start_btn = QPushButton("▶ Start")
        self.start_btn.setStyleSheet("""
            QPushButton {
                background: #2ecc71;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: #27ae60;
            }
            QPushButton:disabled {
                background: #95a5a6;
            }
        """)
        self.start_btn.clicked.connect(self.start_counting)
        self.start_btn.setEnabled(False)
        btn_layout.addWidget(self.start_btn)
        
        self.stop_btn = QPushButton("⏹ Stop")
        self.stop_btn.setStyleSheet("""
            QPushButton {
                background: #e74c3c;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: #c0392b;
            }
            QPushButton:disabled {
                background: #95a5a6;
            }
        """)
        self.stop_btn.clicked.connect(self.stop_counting)
        self.stop_btn.setEnabled(False)
        btn_layout.addWidget(self.stop_btn)
        
        control_layout.addWidget(btn_frame)
        
        # Count display
        count_frame = QGroupBox("Total-Count")
        count_frame.setStyleSheet("""
            QGroupBox {
                background: #2c3e50;
                border: 2px solid #34495e;
                border-radius: 5px;
            }
            QGroupBox::title {
                color: #ecf0f1;
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 3px;
            }
        """)
        count_layout = QVBoxLayout()
        
        self.count_label = QLabel("0")
        self.count_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.count_label.setStyleSheet("""
            QLabel {
                font-size: 36px;
                font-weight: bold;
                color: #f1c40f;
                padding: 15px;
            }
        """)
        count_layout.addWidget(self.count_label)
        
        count_frame.setLayout(count_layout)
        control_layout.addWidget(count_frame)
        
        # Instructions
        instr_frame = QGroupBox("Instructions")
        instr_frame.setStyleSheet("""
            QGroupBox {
                background: #34495e;
                border: 2px solid #2c3e50;
                border-radius: 5px;
            }
            QGroupBox::title {
                color: #ecf0f1;
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 3px;
            }
        """)
        instr_layout = QVBoxLayout()
        
        instructions = [
            "1. Select RTSP camera or upload video",
            "2. 🖌️ Draw counting area",
            "3. 🔒 Fix rectangle position",
            "4. ▶ Start counting",
            "5. Objects counted when center",
            "   enters the counting area",
            "6. ⏹ Stop when finished",
            "7. ▶ Start again to continue",
            "   from where you stopped"
        ]
        
        for instr in instructions:
            label = QLabel(instr)
            label.setStyleSheet("color: #ecf0f1;")
            instr_layout.addWidget(label)
            
        instr_frame.setLayout(instr_layout)
        control_layout.addWidget(instr_frame)
        
        control_layout.addStretch()
        control_panel.setLayout(control_layout)
        main_layout.addWidget(control_panel, stretch=1)
        
        # Right panel - video display
        video_frame = QFrame()
        video_frame.setFrameShape(QFrame.Shape.StyledPanel)
        video_frame.setStyleSheet("background: #2c3e50;")
        video_layout = QVBoxLayout(video_frame)
        
        self.video_widget = VideoWidget()
        self.video_widget.setStyleSheet("background: #000000;")
        video_layout.addWidget(self.video_widget)
        
        main_layout.addWidget(video_frame, stretch=5)
        
    def set_source_selection_enabled(self, enabled):
        """Enable or disable all video source selection controls"""
        self.rtsp_combo.setEnabled(enabled)
        self.custom_rtsp_edit.setEnabled(enabled)
        self.connect_rtsp_btn.setEnabled(enabled)
        self.upload_btn.setEnabled(enabled)
        
    def rtsp_selected(self, text):
        if text == "Custom RTSP":
            self.custom_rtsp_edit.setEnabled(True)
            self.custom_rtsp_edit.setFocus()
        else:
            self.custom_rtsp_edit.setEnabled(False)
            self.custom_rtsp_edit.setCurrentText(self.rtsp_links.get(text, ""))
        
    def connect_to_rtsp(self):
        rtsp_url = self.custom_rtsp_edit.currentText().strip()
        if not rtsp_url:
            # If custom RTSP is empty, use the selected preset
            selected_preset = self.rtsp_combo.currentText()
            rtsp_url = self.rtsp_links.get(selected_preset, "")
            if not rtsp_url:
                return
        
        self.stop_counting()
        
        # Release previous capture if exists
        if self.cap:
            self.cap.release()
        
        try:
            self.cap = cv2.VideoCapture(rtsp_url)
            if not self.cap.isOpened():
                raise Exception("Could not open RTSP stream")
                
            # Read first frame
            ret, frame = self.cap.read()
            if ret:
                frame = cv2.resize(frame, (self.TARGET_WIDTH, self.TARGET_HEIGHT))
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                
                height, width, channel = frame.shape
                bytes_per_line = 3 * width
                q_img = QImage(frame.data, width, height, bytes_per_line, QImage.Format.Format_RGB888)
                
                self.video_widget.set_image(q_img)
                self.draw_btn.setEnabled(True)
                self.current_source = 'rtsp'
                
        except Exception as e:
            print(f"Error connecting to RTSP: {e}")
            if self.cap:
                self.cap.release()
                self.cap = None
    
    def upload_video(self):
        file_dialog = QFileDialog()
        file_path, _ = file_dialog.getOpenFileName(self, "Open Video File", "", "Video Files (*.mp4 *.avi *.mov)")
        
        if file_path:
            self.stop_counting()
            
            # Release previous capture if exists
            if self.cap:
                self.cap.release()
                
            self.video_path = file_path
            self.cap = cv2.VideoCapture(file_path)
            self.current_frame_position = 0  # Reset frame position when new video is loaded
            self.current_source = 'video'
            
            # Read first frame
            ret, frame = self.cap.read()
            if ret:
                frame = cv2.resize(frame, (self.TARGET_WIDTH, self.TARGET_HEIGHT))
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                
                height, width, channel = frame.shape
                bytes_per_line = 3 * width
                q_img = QImage(frame.data, width, height, bytes_per_line, QImage.Format.Format_RGB888)
                
                self.video_widget.set_image(q_img)
                self.draw_btn.setEnabled(True)
    
    def start_drawing_rect(self):
        self.draw_btn.setEnabled(False)
        self.start_btn.setEnabled(True)
        self.fix_btn.setEnabled(True)
        
    def toggle_fix_rectangle(self):
        self.video_widget.fix_rectangle()
        if self.video_widget.fixed:
            self.fix_btn.setText("🔓 Unfix Rectangle")
            self.fix_btn.setStyleSheet("""
                QPushButton {
                    background: #2ecc71;
                    color: white;
                    border: none;
                    padding: 10px;
                    border-radius: 5px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background: #27ae60;
                }
            """)
        else:
            self.fix_btn.setText("🔒 Fix Rectangle")
            self.fix_btn.setStyleSheet("""
                QPushButton {
                    background: #e74c3c;
                    color: white;
                    border: none;
                    padding: 10px;
                    border-radius: 5px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background: #c0392b;
                }
            """)
        
    def start_counting(self):
        if not self.cap:
            return
            
        if self.current_source == 'video':
            # Set the frame position to where we left off (don't reset to 0)
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, self.current_frame_position)
            
        self.playing = True
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        
        # Disable source selection when counting starts
        self.set_source_selection_enabled(False)
        
        self.timer.start(30)
        
    def stop_counting(self):
        if not self.cap:
            return
            
        self.playing = False
        self.timer.stop()
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        
        # Enable source selection when counting stops
        self.set_source_selection_enabled(True)
        
        if self.current_source == 'video':
            # Store the current frame position when stopping
            self.current_frame_position = self.cap.get(cv2.CAP_PROP_POS_FRAMES)
    def update_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            if self.current_source == 'rtsp':
                # For RTSP, try to reconnect
                self.stop_counting()
                self.connect_to_rtsp()
                if self.cap and self.cap.isOpened():
                    self.start_counting()
                return
            else:
                self.stop_counting()
                return
            
        if self.current_source == 'video':
            # Update current frame position for video files
            self.current_frame_position = self.cap.get(cv2.CAP_PROP_POS_FRAMES)
        
        frame = cv2.resize(frame, (self.TARGET_WIDTH, self.TARGET_HEIGHT))
        
        if self.model and self.video_widget.rect:
            rect = self.video_widget.rect
            roi = (rect.x(), rect.y(), rect.width(), rect.height())
            
            results = self.model.track(frame, persist=True, tracker="bytetrack.yaml")
            boxes = results[0].boxes
            
            if boxes is not None:
                for box in boxes:
                    x1, y1, x2, y2 = box.xyxy[0].cpu().numpy().astype(int)
                    track_id = int(box.id[0]) if box.id is not None and len(box.id) > 0 else None
                    
                    if track_id is not None:
                        cx = int((x1 + x2) / 2)
                        cy = int((y1 + y2) / 2)
                        
                        # Initialize track history if not exists
                        if track_id not in self.track_history:
                            self.track_history[track_id] = []
                        
                        # Add current position to track history
                        self.track_history[track_id].append((cx, cy))
                        
                        # Limit track history to last 10 positions
                        if len(self.track_history[track_id]) > 10:
                            self.track_history[track_id] = self.track_history[track_id][-10:]
                        
                        # Check if this ID hasn't been counted yet and is entering the counting area
                        if track_id not in self.counted_ids and rect.contains(QPoint(cx, cy)):
                            # Additional check: make sure the object is moving into the area
                            # by checking previous positions (at least 2 previous positions)
                            if len(self.track_history[track_id]) >= 3:
                                prev_x, prev_y = self.track_history[track_id][-2]  # previous position
                                prev_prev_x, prev_prev_y = self.track_history[track_id][-3]  # position before previous
                                
                                # Calculate movement direction (simple difference)
                                dx = cx - prev_x
                                dy = cy - prev_y
                                
                                # Only count if the object is moving into the area (optional)
                                # This helps prevent counting stationary objects
                                if dx != 0 or dy != 0:
                                    self.cross_count += 1
                                    self.counted_ids.add(track_id)
                                    self.count_label.setText(str(self.cross_count))
                        
                        # Visualization
                        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                        cv2.putText(frame, f'ID:{track_id}', (x1, y1 - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 2)
                        cv2.circle(frame, (cx, cy), 5, (0, 0, 255), -1)
        
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        height, width, channel = frame.shape
        bytes_per_line = 3 * width
        q_img = QImage(frame.data, width, height, bytes_per_line, QImage.Format.Format_RGB888)
        
        self.video_widget.set_image(q_img)   
    
    
    def closeEvent(self, event):
        if self.cap:
            self.cap.release()
        if self.timer.isActive():
            self.timer.stop()
        event.accept()